import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  plugins: [react()], server: { port: 5173, proxy: { '/graphql': 'http://localhost:8080', '/auth': 'http://localhost:8080', '/api': 'http://localhost:8080', '/healthz': 'http://localhost:8080' } }
});
